## Learning Cruve in Machine Learning 🐌

## Need to know for this section 👨🏽‍💻

Please follow this link, it's very helpful.
https://www.dataquest.io/blog/learning-curves-machine-learning/
